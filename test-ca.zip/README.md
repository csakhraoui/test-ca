# Test pour Crédit Agricole Assurance

## Installation

`npm install`

## Build

### Dev
`npm start`

### Prod
`npm run build`

## Demo
Open the file `index.html` in browser.
