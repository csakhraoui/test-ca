export class View {
	static render(model) {
		const tpl = model.render();
		const container = document.createElement('div');
		const content = document.createTextNode();
	}
}
